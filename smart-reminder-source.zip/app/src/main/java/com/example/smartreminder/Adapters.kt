package com.example.smartreminder

import android.graphics.Color
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class ReminderAdapter(
    private var items: List<ReminderItem>,
    private val onDoneClick: (ReminderItem) -> Unit,
    private val onEditClick: (ReminderItem) -> Unit
) : RecyclerView.Adapter<ReminderAdapter.ReminderVH>() {

    class ReminderVH(view: View) : RecyclerView.ViewHolder(view) {
        val tvCategoryBadge: TextView = view.findViewById(R.id.tvCategoryBadge)
        val tvStatusBadge: TextView = view.findViewById(R.id.tvStatusBadge)
        val tvReminderTitle: TextView = view.findViewById(R.id.tvReminderTitle)
        val tvReminderTime: TextView = view.findViewById(R.id.tvReminderTime)
        val tvReminderRepeat: TextView = view.findViewById(R.id.tvReminderRepeat)
        val tvReminderNote: TextView = view.findViewById(R.id.tvReminderNote)
        val btnCardDone: MaterialButton = view.findViewById(R.id.btnCardDone)
        val btnCardEdit: MaterialButton = view.findViewById(R.id.btnCardEdit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReminderVH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_reminder_card, parent, false)
        return ReminderVH(v)
    }

    override fun onBindViewHolder(holder: ReminderVH, position: Int) {
        val item = items[position]
        val now = System.currentTimeMillis()
        val isMissed = !item.isCompleted && (item.triggerTimeMillis + 10 * 60 * 1000L < now)

        holder.tvCategoryBadge.text = item.category.label
        holder.tvCategoryBadge.setBackgroundColor(Color.parseColor(item.category.badgeColorHex))

        when {
            item.isCompleted -> {
                holder.tvStatusBadge.text = "COMPLETED"
                holder.tvStatusBadge.setTextColor(Color.parseColor("#2E7D32"))
                holder.tvStatusBadge.setBackgroundColor(Color.parseColor("#E8F5E9"))
            }
            isMissed -> {
                holder.tvStatusBadge.text = "MISSED (Baki)"
                holder.tvStatusBadge.setTextColor(Color.parseColor("#B71C1C"))
                holder.tvStatusBadge.setBackgroundColor(Color.parseColor("#FFEBEE"))
            }
            else -> {
                holder.tvStatusBadge.text = "UPCOMING"
                holder.tvStatusBadge.setTextColor(Color.parseColor("#0D47A1"))
                holder.tvStatusBadge.setBackgroundColor(Color.parseColor("#E3F2FD"))
            }
        }

        holder.tvReminderTitle.text = item.title
        if (item.isCompleted) {
            holder.tvReminderTitle.paintFlags =
                holder.tvReminderTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        } else {
            holder.tvReminderTitle.paintFlags =
                holder.tvReminderTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
        }

        val dt = LocalDateTime.ofInstant(
            Instant.ofEpochMilli(item.triggerTimeMillis),
            ZoneId.systemDefault()
        )
        val fmt = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy • hh:mm a", Locale.ENGLISH)
        holder.tvReminderTime.text = dt.format(fmt)

        val repeatDesc = when (item.repeatType) {
            RepeatType.EVERY_X_HOURS -> "Repeat: Dar ${item.intervalHours} Kalake"
            RepeatType.MONTHLY -> {
                val datesStr = item.monthlyDays.sorted().joinToString(", ")
                "Repeat: Dar Mahine ($datesStr) Tarikhe"
            }
            else -> "Repeat: ${item.repeatType.label}"
        }
        val preDesc = if (item.preAlertMinutes.isNotEmpty()) {
            " • Pre-alerts: ${item.preAlertMinutes.size}"
        } else {
            ""
        }
        holder.tvReminderRepeat.text = "$repeatDesc$preDesc"

        if (item.note.isNotEmpty()) {
            holder.tvReminderNote.visibility = View.VISIBLE
            holder.tvReminderNote.text = item.note
        } else {
            holder.tvReminderNote.visibility = View.GONE
        }

        holder.btnCardDone.text = if (item.isCompleted) "Done ✓" else "Done"
        holder.btnCardDone.isEnabled = !item.isCompleted

        holder.btnCardDone.setOnClickListener { onDoneClick(item) }
        holder.btnCardEdit.setOnClickListener { onEditClick(item) }
        holder.itemView.setOnClickListener { onEditClick(item) }
    }

    override fun getItemCount(): Int = items.size

    fun updateList(newItems: List<ReminderItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}

class WeeklyPlanAdapter(
    private var days: List<WeeklyPlanDay>,
    private val onEditDay: (WeeklyPlanDay) -> Unit
) : RecyclerView.Adapter<WeeklyPlanAdapter.WeekVH>() {

    class WeekVH(view: View) : RecyclerView.ViewHolder(view) {
        val tvWeekDayTitle: TextView = view.findViewById(R.id.tvWeekDayTitle)
        val tvWeekMeal: TextView = view.findViewById(R.id.tvWeekMeal)
        val tvWeekSchedule: TextView = view.findViewById(R.id.tvWeekSchedule)
        val btnEditWeekDay: MaterialButton = view.findViewById(R.id.btnEditWeekDay)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeekVH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_weekly_day, parent, false)
        return WeekVH(v)
    }

    override fun onBindViewHolder(holder: WeekVH, position: Int) {
        val d = days[position]
        holder.tvWeekDayTitle.text = d.dayTitle
        holder.tvWeekMeal.text = "🍽️ Meal: ${d.mealPlan.ifEmpty { "Set nathi" }}"
        holder.tvWeekSchedule.text = "📅 Activity: ${d.schedulePlan.ifEmpty { "Set nathi" }}"
        holder.btnEditWeekDay.setOnClickListener { onEditDay(d) }
        holder.itemView.setOnClickListener { onEditDay(d) }
    }

    override fun getItemCount(): Int = days.size

    fun updateDays(newDays: List<WeeklyPlanDay>) {
        days = newDays
        notifyDataSetChanged()
    }
}

class HistoryAdapter(
    private var logs: List<HistoryLog>
) : RecyclerView.Adapter<HistoryAdapter.HistVH>() {

    class HistVH(view: View) : RecyclerView.ViewHolder(view) {
        val tvHistStatus: TextView = view.findViewById(R.id.tvHistStatus)
        val tvHistTitle: TextView = view.findViewById(R.id.tvHistTitle)
        val tvHistMeta: TextView = view.findViewById(R.id.tvHistMeta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistVH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history_row, parent, false)
        return HistVH(v)
    }

    override fun onBindViewHolder(holder: HistVH, position: Int) {
        val log = logs[position]
        if (log.isCompleted) {
            holder.tvHistStatus.text = "✓ COMPLETED"
            holder.tvHistStatus.setTextColor(Color.parseColor("#2E7D32"))
        } else {
            holder.tvHistStatus.text = "⚠ MISSED"
            holder.tvHistStatus.setTextColor(Color.parseColor("#C62828"))
        }
        holder.tvHistTitle.text = log.title
        val dt = LocalDateTime.ofInstant(
            Instant.ofEpochMilli(log.actionTimeMillis),
            ZoneId.systemDefault()
        )
        val fmt = DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a", Locale.ENGLISH)
        holder.tvHistMeta.text = "${log.category.label} • ${dt.format(fmt)}"
    }

    override fun getItemCount(): Int = logs.size

    fun updateLogs(newLogs: List<HistoryLog>) {
        logs = newLogs
        notifyDataSetChanged()
    }
}
