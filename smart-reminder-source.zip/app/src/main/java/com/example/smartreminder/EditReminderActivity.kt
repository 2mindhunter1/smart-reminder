package com.example.smartreminder

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.switchmaterial.SwitchMaterial
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

class EditReminderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_EDIT_ID = "extra_edit_id"
    }

    private lateinit var tvFormHeader: TextView
    private lateinit var etTitle: EditText
    private lateinit var etNote: EditText

    private lateinit var chipCatMedicine: Chip
    private lateinit var chipCatSchool: Chip
    private lateinit var chipCatBills: Chip
    private lateinit var chipCatDaily: Chip

    private lateinit var btnPickDate: MaterialButton
    private lateinit var btnPickTime: MaterialButton

    private lateinit var rgRepeatType: RadioGroup
    private lateinit var layoutHourlyBox: LinearLayout
    private lateinit var etIntervalHours: EditText
    private lateinit var layoutWeeklyBox: LinearLayout
    private lateinit var layoutMonthlyBox: LinearLayout
    private lateinit var tvSelectedMonthlyDates: TextView
    private lateinit var gridMonthlyDates: GridLayout

    private lateinit var chipDayMon: Chip
    private lateinit var chipDayTue: Chip
    private lateinit var chipDayWed: Chip
    private lateinit var chipDayThu: Chip
    private lateinit var chipDayFri: Chip
    private lateinit var chipDaySat: Chip
    private lateinit var chipDaySun: Chip

    private lateinit var chipPre15m: Chip
    private lateinit var chipPre1h: Chip
    private lateinit var chipPre2h: Chip
    private lateinit var chipPre1d: Chip

    private lateinit var switchFullAlarm: SwitchMaterial
    private lateinit var btnSaveReminder: MaterialButton
    private lateinit var btnDeleteReminder: MaterialButton

    private var editingItem: ReminderItem? = null
    private var selectedDate: LocalDate = LocalDate.now()
    private var selectedTime: LocalTime = LocalTime.now().plusHours(1).withMinute(0)
    private val selectedMonthlyDays = mutableSetOf<Int>()
    private val dateButtonsMap = mutableMapOf<Int, TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_reminder)

        val root: View = findViewById(R.id.editRootLayout)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        tvFormHeader = findViewById(R.id.tvFormHeader)
        etTitle = findViewById(R.id.etTitle)
        etNote = findViewById(R.id.etNote)

        chipCatMedicine = findViewById(R.id.chipCatMedicine)
        chipCatSchool = findViewById(R.id.chipCatSchool)
        chipCatBills = findViewById(R.id.chipCatBills)
        chipCatDaily = findViewById(R.id.chipCatDaily)

        btnPickDate = findViewById(R.id.btnPickDate)
        btnPickTime = findViewById(R.id.btnPickTime)

        rgRepeatType = findViewById(R.id.rgRepeatType)
        layoutHourlyBox = findViewById(R.id.layoutHourlyBox)
        etIntervalHours = findViewById(R.id.etIntervalHours)
        layoutWeeklyBox = findViewById(R.id.layoutWeeklyBox)
        layoutMonthlyBox = findViewById(R.id.layoutMonthlyBox)
        tvSelectedMonthlyDates = findViewById(R.id.tvSelectedMonthlyDates)
        gridMonthlyDates = findViewById(R.id.gridMonthlyDates)

        chipDayMon = findViewById(R.id.chipDayMon)
        chipDayTue = findViewById(R.id.chipDayTue)
        chipDayWed = findViewById(R.id.chipDayWed)
        chipDayThu = findViewById(R.id.chipDayThu)
        chipDayFri = findViewById(R.id.chipDayFri)
        chipDaySat = findViewById(R.id.chipDaySat)
        chipDaySun = findViewById(R.id.chipDaySun)

        chipPre15m = findViewById(R.id.chipPre15m)
        chipPre1h = findViewById(R.id.chipPre1h)
        chipPre2h = findViewById(R.id.chipPre2h)
        chipPre1d = findViewById(R.id.chipPre1d)

        switchFullAlarm = findViewById(R.id.switchFullAlarm)
        btnSaveReminder = findViewById(R.id.btnSaveReminder)
        btnDeleteReminder = findViewById(R.id.btnDeleteReminder)

        val btnBackForm: MaterialButton = findViewById(R.id.btnBackForm)
        btnBackForm.setOnClickListener { finish() }

        buildMonthlyDateGrid()

        // Quick 1-Tap Templates
        findViewById<Chip>(R.id.chipTplDava).setOnClickListener {
            etTitle.setText("Dava levani chhe")
            etNote.setText("Jamya pachhi dose levo")
            chipCatMedicine.isChecked = true
            rgRepeatType.check(R.id.rbDaily)
        }
        findViewById<Chip>(R.id.chipTplBill).setOnClickListener {
            etTitle.setText("Vijli / Mobile Bill bharvanu chhe")
            etNote.setText("Dar mahine fixed tarikhe")
            chipCatBills.isChecked = true
            rgRepeatType.check(R.id.rbMonthly)
            selectedMonthlyDays.clear()
            selectedMonthlyDays.add(5)
            refreshMonthlyDateGridUI()
            chipPre1d.isChecked = true
        }
        findViewById<Chip>(R.id.chipTplSchool).setOnClickListener {
            etTitle.setText("School ni Fee / PTM yaad")
            etNote.setText("Maharshi ni school schedule")
            chipCatSchool.isChecked = true
            chipPre1d.isChecked = true
            chipPre2h.isChecked = true
        }
        findViewById<Chip>(R.id.chipTplDoctor).setOnClickListener {
            etTitle.setText("Doctor Checkup Appointment")
            etNote.setText("Juna report sathe rakhva")
            chipCatMedicine.isChecked = true
            chipPre1d.isChecked = true
            chipPre2h.isChecked = true
        }

        rgRepeatType.setOnCheckedChangeListener { _, checkedId ->
            layoutHourlyBox.visibility = if (checkedId == R.id.rbFrequentHours) View.VISIBLE else View.GONE
            layoutWeeklyBox.visibility = if (checkedId == R.id.rbWeekly) View.VISIBLE else View.GONE
            layoutMonthlyBox.visibility = if (checkedId == R.id.rbMonthly) View.VISIBLE else View.GONE
        }

        btnPickDate.setOnClickListener {
            DatePickerDialog(
                this,
                { _, y, m, d ->
                    selectedDate = LocalDate.of(y, m + 1, d)
                    if (selectedMonthlyDays.isEmpty()) {
                        selectedMonthlyDays.add(d)
                        refreshMonthlyDateGridUI()
                    }
                    refreshDateTimeButtons()
                },
                selectedDate.year,
                selectedDate.monthValue - 1,
                selectedDate.dayOfMonth
            ).show()
        }

        btnPickTime.setOnClickListener {
            TimePickerDialog(
                this,
                { _, h, min ->
                    selectedTime = LocalTime.of(h, min)
                    refreshDateTimeButtons()
                },
                selectedTime.hour,
                selectedTime.minute,
                false
            ).show()
        }

        val editId = intent.getStringExtra(EXTRA_EDIT_ID)
        if (editId != null) {
            editingItem = ReminderRepository.getReminderById(this, editId)
        }

        if (editingItem != null) {
            populateForm(editingItem!!)
        } else {
            tvFormHeader.text = "Navu Reminder Set Karo"
            btnDeleteReminder.visibility = View.GONE
            chipCatDaily.isChecked = true
            rgRepeatType.check(R.id.rbOnce)
            selectedMonthlyDays.add(selectedDate.dayOfMonth)
            refreshMonthlyDateGridUI()
            refreshDateTimeButtons()
        }

        btnSaveReminder.setOnClickListener { saveForm() }

        btnDeleteReminder.setOnClickListener {
            val target = editingItem ?: return@setOnClickListener
            AlertDialog.Builder(this)
                .setTitle("Reminder Delete Karvu Chhe?")
                .setMessage("'${target.title}' hamesha mate delete thai jase.")
                .setPositiveButton("Delete") { _, _ ->
                    ReminderRepository.deleteReminder(this, target.id)
                    Toast.makeText(this, "Reminder delete thai gayu", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun buildMonthlyDateGrid() {
        gridMonthlyDates.removeAllViews()
        dateButtonsMap.clear()
        val density = resources.displayMetrics.density
        val marginPx = (3 * density).toInt()
        val heightPx = (38 * density).toInt()

        for (day in 1..31) {
            val tv = TextView(this).apply {
                text = day.toString()
                gravity = Gravity.CENTER
                textSize = 13f
                setPadding(0, 4, 0, 4)
            }
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = heightPx
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(marginPx, marginPx, marginPx, marginPx)
            }
            tv.layoutParams = params
            tv.setOnClickListener {
                if (day in selectedMonthlyDays) {
                    if (selectedMonthlyDays.size > 1) {
                        selectedMonthlyDays.remove(day)
                    } else {
                        Toast.makeText(this, "Kam se kam 1 tarikh pasand rakhvi jaroori chhe", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    selectedMonthlyDays.add(day)
                }
                refreshMonthlyDateGridUI()
            }
            dateButtonsMap[day] = tv
            gridMonthlyDates.addView(tv)
        }
    }

    private fun refreshMonthlyDateGridUI() {
        for ((day, tv) in dateButtonsMap) {
            val isSelected = day in selectedMonthlyDays
            if (isSelected) {
                tv.setBackgroundResource(R.drawable.bg_date_chip_selected)
                tv.setTextColor(Color.WHITE)
            } else {
                tv.setBackgroundResource(R.drawable.bg_date_chip_normal)
                tv.setTextColor(Color.parseColor("#1C1B1F"))
            }
        }
        val sortedList = selectedMonthlyDays.sorted()
        tvSelectedMonthlyDates.text = if (sortedList.isEmpty()) {
            "Pasand kareli tarikho: Koi nathi"
        } else {
            "Pasand kareli tarikho: ${sortedList.joinToString(", ")}"
        }
    }

    private fun populateForm(item: ReminderItem) {
        tvFormHeader.text = "Reminder Edit Karo"
        btnDeleteReminder.visibility = View.VISIBLE
        etTitle.setText(item.title)
        etNote.setText(item.note)

        when (item.category) {
            ReminderCategory.MEDICINE -> chipCatMedicine.isChecked = true
            ReminderCategory.SCHOOL -> chipCatSchool.isChecked = true
            ReminderCategory.BILLS -> chipCatBills.isChecked = true
            ReminderCategory.DAILY -> chipCatDaily.isChecked = true
        }

        val dt = LocalDateTime.ofInstant(
            java.time.Instant.ofEpochMilli(item.triggerTimeMillis),
            ZoneId.systemDefault()
        )
        selectedDate = dt.toLocalDate()
        selectedTime = dt.toLocalTime()
        refreshDateTimeButtons()

        etIntervalHours.setText(item.intervalHours.toString())

        selectedMonthlyDays.clear()
        selectedMonthlyDays.addAll(item.monthlyDays.ifEmpty { listOf(selectedDate.dayOfMonth) })
        refreshMonthlyDateGridUI()

        chipDayMon.isChecked = 1 in item.weeklyDays
        chipDayTue.isChecked = 2 in item.weeklyDays
        chipDayWed.isChecked = 3 in item.weeklyDays
        chipDayThu.isChecked = 4 in item.weeklyDays
        chipDayFri.isChecked = 5 in item.weeklyDays
        chipDaySat.isChecked = 6 in item.weeklyDays
        chipDaySun.isChecked = 7 in item.weeklyDays

        when (item.repeatType) {
            RepeatType.ONCE -> rgRepeatType.check(R.id.rbOnce)
            RepeatType.DAILY -> rgRepeatType.check(R.id.rbDaily)
            RepeatType.ALTERNATE_DAY -> rgRepeatType.check(R.id.rbAlternateDay)
            RepeatType.EVERY_X_HOURS -> rgRepeatType.check(R.id.rbFrequentHours)
            RepeatType.WEEKLY -> rgRepeatType.check(R.id.rbWeekly)
            RepeatType.MONTHLY -> rgRepeatType.check(R.id.rbMonthly)
        }

        chipPre15m.isChecked = 15 in item.preAlertMinutes
        chipPre1h.isChecked = 60 in item.preAlertMinutes
        chipPre2h.isChecked = 120 in item.preAlertMinutes
        chipPre1d.isChecked = 1440 in item.preAlertMinutes

        switchFullAlarm.isChecked = item.fullScreenAlarm
    }

    private fun refreshDateTimeButtons() {
        val dFmt = DateTimeFormatter.ofPattern("dd MMM yyyy (EEE)", Locale.ENGLISH)
        val tFmt = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH)
        btnPickDate.text = "📅 ${selectedDate.format(dFmt)}"
        btnPickTime.text = "⏰ ${selectedTime.format(tFmt)}"
    }

    private fun saveForm() {
        val title = etTitle.text.toString().trim()
        if (title.isEmpty()) {
            etTitle.error = "Kaam nu naam lakho"
            etTitle.requestFocus()
            return
        }
        val note = etNote.text.toString().trim()

        val category = when {
            chipCatMedicine.isChecked -> ReminderCategory.MEDICINE
            chipCatSchool.isChecked -> ReminderCategory.SCHOOL
            chipCatBills.isChecked -> ReminderCategory.BILLS
            else -> ReminderCategory.DAILY
        }

        val repeatType = when (rgRepeatType.checkedRadioButtonId) {
            R.id.rbDaily -> RepeatType.DAILY
            R.id.rbAlternateDay -> RepeatType.ALTERNATE_DAY
            R.id.rbFrequentHours -> RepeatType.EVERY_X_HOURS
            R.id.rbWeekly -> RepeatType.WEEKLY
            R.id.rbMonthly -> RepeatType.MONTHLY
            else -> RepeatType.ONCE
        }

        val intervalHours = (etIntervalHours.text.toString().toIntOrNull() ?: 4).coerceIn(1, 72)

        val monthlyList = selectedMonthlyDays
            .filter { it in 1..31 }
            .distinct()
            .sorted()
            .ifEmpty { listOf(selectedDate.dayOfMonth) }

        val weeklyDays = mutableListOf<Int>()
        if (chipDayMon.isChecked) weeklyDays.add(1)
        if (chipDayTue.isChecked) weeklyDays.add(2)
        if (chipDayWed.isChecked) weeklyDays.add(3)
        if (chipDayThu.isChecked) weeklyDays.add(4)
        if (chipDayFri.isChecked) weeklyDays.add(5)
        if (chipDaySat.isChecked) weeklyDays.add(6)
        if (chipDaySun.isChecked) weeklyDays.add(7)
        if (repeatType == RepeatType.WEEKLY && weeklyDays.isEmpty()) {
            weeklyDays.add(selectedDate.dayOfWeek.value)
        }

        val preAlerts = mutableListOf<Int>()
        if (chipPre15m.isChecked) preAlerts.add(15)
        if (chipPre1h.isChecked) preAlerts.add(60)
        if (chipPre2h.isChecked) preAlerts.add(120)
        if (chipPre1d.isChecked) preAlerts.add(1440)

        val zone = ZoneId.systemDefault()
        val chosenDateTime = LocalDateTime.of(selectedDate, selectedTime)
        var triggerMillis = chosenDateTime.atZone(zone).toInstant().toEpochMilli()

        val draft = ReminderItem(
            id = editingItem?.id ?: UUID.randomUUID().toString(),
            title = title,
            note = note,
            category = category,
            triggerTimeMillis = triggerMillis,
            repeatType = repeatType,
            intervalHours = intervalHours,
            weeklyDays = weeklyDays,
            monthlyDays = monthlyList,
            preAlertMinutes = preAlerts,
            fullScreenAlarm = switchFullAlarm.isChecked,
            isCompleted = false,
            completedCount = editingItem?.completedCount ?: 0,
            missedCount = editingItem?.missedCount ?: 0
        )

        if (repeatType == RepeatType.MONTHLY || repeatType == RepeatType.WEEKLY) {
            triggerMillis = ReminderRepository.computeNextOccurrenceMillis(draft, System.currentTimeMillis())
        } else if (repeatType != RepeatType.ONCE && triggerMillis <= System.currentTimeMillis()) {
            triggerMillis = ReminderRepository.computeNextOccurrenceMillis(draft, System.currentTimeMillis())
        }

        val finalItem = draft.copy(triggerTimeMillis = triggerMillis)
        ReminderRepository.upsertReminder(this, finalItem)
        Toast.makeText(this, "Reminder save thai gayu!", Toast.LENGTH_SHORT).show()
        finish()
    }
}
