package com.example.smartreminder

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatToday: TextView
    private lateinit var tvStatMissed: TextView
    private lateinit var tvStatDone: TextView

    private lateinit var cardPermissionAlert: View
    private lateinit var btnGrantFullScreen: MaterialButton
    private lateinit var btnGrantOverlay: MaterialButton

    private lateinit var sectionReminders: View
    private lateinit var sectionWeekly: View
    private lateinit var sectionHistory: View

    private lateinit var recyclerReminders: RecyclerView
    private lateinit var tvEmptyReminders: TextView
    private lateinit var recyclerWeekly: RecyclerView
    private lateinit var recyclerHistory: RecyclerView
    private lateinit var tvEmptyHistory: TextView
    private lateinit var fabAddReminder: ExtendedFloatingActionButton

    private lateinit var reminderAdapter: ReminderAdapter
    private lateinit var weeklyAdapter: WeeklyPlanAdapter
    private lateinit var historyAdapter: HistoryAdapter

    private var activeFilter: String = "ALL"

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        checkAutoFullScreenPermissions()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root: View = findViewById(R.id.mainRootLayout)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        requestNotificationPermissionIfNeeded()

        tvStatToday = findViewById(R.id.tvStatToday)
        tvStatMissed = findViewById(R.id.tvStatMissed)
        tvStatDone = findViewById(R.id.tvStatDone)

        cardPermissionAlert = findViewById(R.id.cardPermissionAlert)
        btnGrantFullScreen = findViewById(R.id.btnGrantFullScreen)
        btnGrantOverlay = findViewById(R.id.btnGrantOverlay)

        sectionReminders = findViewById(R.id.sectionReminders)
        sectionWeekly = findViewById(R.id.sectionWeekly)
        sectionHistory = findViewById(R.id.sectionHistory)

        recyclerReminders = findViewById(R.id.recyclerReminders)
        tvEmptyReminders = findViewById(R.id.tvEmptyReminders)
        recyclerWeekly = findViewById(R.id.recyclerWeekly)
        recyclerHistory = findViewById(R.id.recyclerHistory)
        tvEmptyHistory = findViewById(R.id.tvEmptyHistory)
        fabAddReminder = findViewById(R.id.fabAddReminder)

        btnGrantFullScreen.setOnClickListener {
            openFullScreenPermissionSettings()
        }

        btnGrantOverlay.setOnClickListener {
            openOverlayPermissionSettings()
        }

        recyclerReminders.layoutManager = LinearLayoutManager(this)
        reminderAdapter = ReminderAdapter(
            items = emptyList(),
            onDoneClick = { item ->
                ReminderRepository.markReminderDone(this, item.id)
                Toast.makeText(this, "Done! Reminder update thai gayu", Toast.LENGTH_SHORT).show()
                refreshAllViews()
            },
            onEditClick = { item ->
                val intent = Intent(this, EditReminderActivity::class.java).apply {
                    putExtra(EditReminderActivity.EXTRA_EDIT_ID, item.id)
                }
                startActivity(intent)
            }
        )
        recyclerReminders.adapter = reminderAdapter

        recyclerWeekly.layoutManager = LinearLayoutManager(this)
        weeklyAdapter = WeeklyPlanAdapter(emptyList()) { day ->
            showEditWeeklyDayDialog(day)
        }
        recyclerWeekly.adapter = weeklyAdapter

        recyclerHistory.layoutManager = LinearLayoutManager(this)
        historyAdapter = HistoryAdapter(emptyList())
        recyclerHistory.adapter = historyAdapter

        setupCategoryFilterChips()

        fabAddReminder.setOnClickListener {
            startActivity(Intent(this, EditReminderActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnClearHistory).setOnClickListener {
            ReminderRepository.clearHistory(this)
            refreshAllViews()
            Toast.makeText(this, "History clear thai gayi", Toast.LENGTH_SHORT).show()
        }

        val bottomNav: BottomNavigationView = findViewById(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_reminders -> {
                    sectionReminders.visibility = View.VISIBLE
                    sectionWeekly.visibility = View.GONE
                    sectionHistory.visibility = View.GONE
                    fabAddReminder.show()
                    true
                }
                R.id.nav_weekly -> {
                    sectionReminders.visibility = View.GONE
                    sectionWeekly.visibility = View.VISIBLE
                    sectionHistory.visibility = View.GONE
                    fabAddReminder.hide()
                    true
                }
                R.id.nav_history -> {
                    sectionReminders.visibility = View.GONE
                    sectionWeekly.visibility = View.GONE
                    sectionHistory.visibility = View.VISIBLE
                    fabAddReminder.hide()
                    true
                }
                else -> false
            }
        }

        ReminderRepository.ensureSeeded(this)
        AlarmScheduler.rescheduleAll(this)
    }

    override fun onResume() {
        super.onResume()
        checkAutoFullScreenPermissions()
        ReminderRepository.syncMissedReminders(this)
        refreshAllViews()
    }

    private fun checkAutoFullScreenPermissions() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val canFullScreen = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            nm.canUseFullScreenIntent()
        } else {
            true
        }
        val canOverlay = Settings.canDrawOverlays(this)

        if (canFullScreen && canOverlay) {
            cardPermissionAlert.visibility = View.GONE
        } else {
            cardPermissionAlert.visibility = View.VISIBLE
            btnGrantFullScreen.visibility = if (canFullScreen) View.GONE else View.VISIBLE
            btnGrantOverlay.visibility = if (canOverlay) View.GONE else View.VISIBLE
        }
    }

    private fun openFullScreenPermissionSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }
        openAppDetailsSettings()
    }

    private fun openOverlayPermissionSettings() {
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } catch (_: Exception) {
            openAppDetailsSettings()
        }
    }

    private fun openAppDetailsSettings() {
        try {
            val intent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } catch (_: Exception) {
        }
    }

    private fun setupCategoryFilterChips() {
        val chipAll: Chip = findViewById(R.id.chipFilterAll)
        val chipMissed: Chip = findViewById(R.id.chipFilterMissed)
        val chipMed: Chip = findViewById(R.id.chipFilterMed)
        val chipSchool: Chip = findViewById(R.id.chipFilterSchool)
        val chipBills: Chip = findViewById(R.id.chipFilterBills)
        val chipDaily: Chip = findViewById(R.id.chipFilterDaily)

        chipAll.setOnClickListener { activeFilter = "ALL"; refreshAllViews() }
        chipMissed.setOnClickListener { activeFilter = "MISSED"; refreshAllViews() }
        chipMed.setOnClickListener { activeFilter = ReminderCategory.MEDICINE.name; refreshAllViews() }
        chipSchool.setOnClickListener { activeFilter = ReminderCategory.SCHOOL.name; refreshAllViews() }
        chipBills.setOnClickListener { activeFilter = ReminderCategory.BILLS.name; refreshAllViews() }
        chipDaily.setOnClickListener { activeFilter = ReminderCategory.DAILY.name; refreshAllViews() }
    }

    private fun refreshAllViews() {
        val all = ReminderRepository.getAllReminders(this)
        val now = System.currentTimeMillis()
        val zone = ZoneId.systemDefault()
        val todayEnd = LocalDate.now(zone).plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()

        val todayCount = all.count { !it.isCompleted && it.triggerTimeMillis <= todayEnd }
        val missedCount = all.count { !it.isCompleted && (it.triggerTimeMillis + 10 * 60 * 1000L < now) }
        val logs = ReminderRepository.getHistoryLogs(this)
        val doneCount = logs.count { it.isCompleted }

        tvStatToday.text = todayCount.toString()
        tvStatMissed.text = missedCount.toString()
        tvStatDone.text = doneCount.toString()

        val filtered = when (activeFilter) {
            "ALL" -> all
            "MISSED" -> all.filter { !it.isCompleted && (it.triggerTimeMillis + 10 * 60 * 1000L < now) }
            else -> all.filter { it.category.name == activeFilter }
        }

        reminderAdapter.updateList(filtered)
        tvEmptyReminders.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE

        weeklyAdapter.updateDays(ReminderRepository.getWeeklyPlan(this))

        historyAdapter.updateLogs(logs)
        tvEmptyHistory.visibility = if (logs.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showEditWeeklyDayDialog(day: WeeklyPlanDay) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_weekly, null)
        val etMeal: EditText = dialogView.findViewById(R.id.etDialogMeal)
        val etSchedule: EditText = dialogView.findViewById(R.id.etDialogSchedule)

        etMeal.setText(day.mealPlan)
        etSchedule.setText(day.schedulePlan)

        AlertDialog.Builder(this)
            .setTitle("${day.dayTitle} Edit Karo")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val updated = day.copy(
                    mealPlan = etMeal.text.toString().trim(),
                    schedulePlan = etSchedule.text.toString().trim()
                )
                ReminderRepository.updateWeeklyDay(this, updated)
                refreshAllViews()
                Toast.makeText(this, "${day.dayTitle} update thai gayu!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
