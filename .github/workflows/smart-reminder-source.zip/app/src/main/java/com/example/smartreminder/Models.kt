package com.example.smartreminder

enum class ReminderCategory(val label: String, val badgeColorHex: String) {
    MEDICINE("Dava & Doctor", "#C62828"),
    SCHOOL("School & Kids", "#1565C0"),
    BILLS("Bills & Ghar", "#EF6C00"),
    DAILY("Rojinda Kaam", "#2E7D32");

    companion object {
        fun fromName(name: String): ReminderCategory {
            return entries.firstOrNull { it.name == name } ?: DAILY
        }
    }
}

enum class RepeatType(val label: String) {
    ONCE("Ek Vaar (Once)"),
    DAILY("Roj (Daily)"),
    ALTERNATE_DAY("Ek Divas Chhodi Ne (Alternate Day)"),
    EVERY_X_HOURS("Dar Thoda Kalake (Frequent Hours)"),
    WEEKLY("Dar Aathvadiye (Weekly)"),
    MONTHLY("Dar Mahine Tarikhe (Monthly)");

    companion object {
        fun fromName(name: String): RepeatType {
            return entries.firstOrNull { it.name == name } ?: ONCE
        }
    }
}

data class ReminderItem(
    val id: String,
    val title: String,
    val note: String,
    val category: ReminderCategory,
    val triggerTimeMillis: Long,
    val repeatType: RepeatType,
    val intervalHours: Int = 4,
    val weeklyDays: List<Int> = emptyList(), // 1=Mon .. 7=Sun
    val monthlyDay: Int = 1,
    val preAlertMinutes: List<Int> = emptyList(), // e.g. [1440, 120, 15]
    val fullScreenAlarm: Boolean = true,
    val isCompleted: Boolean = false,
    val completedCount: Int = 0,
    val missedCount: Int = 0
)

data class HistoryLog(
    val id: String,
    val reminderId: String,
    val title: String,
    val category: ReminderCategory,
    val scheduledTimeMillis: Long,
    val actionTimeMillis: Long,
    val isCompleted: Boolean
)

data class WeeklyPlanDay(
    val dayOfWeek: Int, // 1=Mon .. 7=Sun
    val dayTitle: String,
    val mealPlan: String,
    val schedulePlan: String
)
