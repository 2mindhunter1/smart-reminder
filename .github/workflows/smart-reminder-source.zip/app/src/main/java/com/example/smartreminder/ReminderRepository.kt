package com.example.smartreminder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import java.util.UUID

object ReminderRepository {

    private const val PREFS_NAME = "smart_reminder_prefs_v1"
    private const val KEY_REMINDERS = "reminders_json"
    private const val KEY_HISTORY = "history_json"
    private const val KEY_WEEKLY = "weekly_plan_json"
    private const val KEY_INITIALIZED = "seeded_defaults_v1"
    private const val KEY_MISSED_KEYS = "missed_logged_keys_json"

    fun ensureSeeded(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_INITIALIZED, false)) return

        val zone = ZoneId.systemDefault()
        val now = LocalDateTime.now(zone)

        val nextFriday = now.with(TemporalAdjusters.nextOrSame(DayOfWeek.FRIDAY))
            .withHour(8).withMinute(0).withSecond(0).withNano(0)
        val fridayMillis = if (nextFriday.isAfter(now)) {
            nextFriday.atZone(zone).toInstant().toEpochMilli()
        } else {
            nextFriday.plusWeeks(1).atZone(zone).toInstant().toEpochMilli()
        }

        val tomorrow11 = now.plusDays(1).withHour(11).withMinute(0).withSecond(0).withNano(0)
            .atZone(zone).toInstant().toEpochMilli()

        val next5thBase = now.withDayOfMonth(5).withHour(10).withMinute(0).withSecond(0).withNano(0)
        val next5thMillis = if (next5thBase.isAfter(now)) {
            next5thBase.atZone(zone).toInstant().toEpochMilli()
        } else {
            next5thBase.plusMonths(1).atZone(zone).toInstant().toEpochMilli()
        }

        val medTime = now.plusHours(2).withMinute(0).withSecond(0).withNano(0)
            .atZone(zone).toInstant().toEpochMilli()

        val defaults = listOf(
            ReminderItem(
                id = UUID.randomUUID().toString(),
                title = "Maharshi no Sports Day chhe",
                note = "School uniform ane water bottle ready rakhvi",
                category = ReminderCategory.SCHOOL,
                triggerTimeMillis = fridayMillis,
                repeatType = RepeatType.WEEKLY,
                weeklyDays = listOf(5),
                preAlertMinutes = listOf(1440, 120),
                fullScreenAlarm = true
            ),
            ReminderItem(
                id = UUID.randomUUID().toString(),
                title = "Savare 11 vagye Mummy nu Checkup chhe",
                note = "Juna report ane file sathe leva",
                category = ReminderCategory.MEDICINE,
                triggerTimeMillis = tomorrow11,
                repeatType = RepeatType.ONCE,
                preAlertMinutes = listOf(1440, 120),
                fullScreenAlarm = true
            ),
            ReminderItem(
                id = UUID.randomUUID().toString(),
                title = "Vijli nu Bill bharvanu chhe",
                note = "Dar mahine 5 tarikhe PGVCL bill",
                category = ReminderCategory.BILLS,
                triggerTimeMillis = next5thMillis,
                repeatType = RepeatType.MONTHLY,
                monthlyDay = 5,
                preAlertMinutes = listOf(1440),
                fullScreenAlarm = true
            ),
            ReminderItem(
                id = UUID.randomUUID().toString(),
                title = "Dava levani chhe",
                note = "Jamya pachhi regular dose",
                category = ReminderCategory.MEDICINE,
                triggerTimeMillis = medTime,
                repeatType = RepeatType.EVERY_X_HOURS,
                intervalHours = 6,
                preAlertMinutes = emptyList(),
                fullScreenAlarm = true
            )
        )
        saveAllReminders(context, defaults)

        val defaultWeekly = listOf(
            WeeklyPlanDay(1, "Somvar (Monday)", "Rotli, Shaak, Dal-Bhat", "School Fees / Office Planning"),
            WeeklyPlanDay(2, "Mangalvar (Tuesday)", "Bhakhri, Kathol, Khichdi", "Evening Walk / Kids Homework"),
            WeeklyPlanDay(3, "Budhvar (Wednesday)", "Thepla, Sukhi Bhaji, Kadhi", "5:00 PM - Swim / Sports Practice"),
            WeeklyPlanDay(4, "Guruvar (Thursday)", "Puri-Shaak / Pulav", "Grocery & Home Shopping Check"),
            WeeklyPlanDay(5, "Shukravar (Friday)", "Handvo / Pav Bhaji", "School Activity / Sports Day"),
            WeeklyPlanDay(6, "Shanivar (Saturday)", "Pizza / Special Nashto", "8:00 AM - Morning Practice & Family Time"),
            WeeklyPlanDay(7, "Ravivar (Sunday)", "Full Gujarati Thali / Dal-Bati", "Rest & Next Week Prep")
        )
        saveWeeklyPlan(context, defaultWeekly)

        prefs.edit().putBoolean(KEY_INITIALIZED, true).apply()
    }

    fun getAllReminders(context: Context): List<ReminderItem> {
        ensureSeeded(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_REMINDERS, "[]") ?: "[]"
        val list = mutableListOf<ReminderItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val wDays = mutableListOf<Int>()
                val wArr = o.optJSONArray("weeklyDays")
                if (wArr != null) {
                    for (j in 0 until wArr.length()) wDays.add(wArr.getInt(j))
                }
                val pMins = mutableListOf<Int>()
                val pArr = o.optJSONArray("preAlertMinutes")
                if (pArr != null) {
                    for (j in 0 until pArr.length()) pMins.add(pArr.getInt(j))
                }
                list.add(
                    ReminderItem(
                        id = o.getString("id"),
                        title = o.getString("title"),
                        note = o.optString("note", ""),
                        category = ReminderCategory.fromName(o.optString("category", "DAILY")),
                        triggerTimeMillis = o.getLong("triggerTimeMillis"),
                        repeatType = RepeatType.fromName(o.optString("repeatType", "ONCE")),
                        intervalHours = o.optInt("intervalHours", 4).coerceAtLeast(1),
                        weeklyDays = wDays,
                        monthlyDay = o.optInt("monthlyDay", 1).coerceIn(1, 31),
                        preAlertMinutes = pMins,
                        fullScreenAlarm = o.optBoolean("fullScreenAlarm", true),
                        isCompleted = o.optBoolean("isCompleted", false),
                        completedCount = o.optInt("completedCount", 0),
                        missedCount = o.optInt("missedCount", 0)
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list.sortedWith(compareBy<ReminderItem> { it.isCompleted }.thenBy { it.triggerTimeMillis })
    }

    fun getReminderById(context: Context, id: String): ReminderItem? {
        return getAllReminders(context).firstOrNull { it.id == id }
    }

    fun saveAllReminders(context: Context, items: List<ReminderItem>) {
        val arr = JSONArray()
        for (item in items) {
            val o = JSONObject()
            o.put("id", item.id)
            o.put("title", item.title)
            o.put("note", item.note)
            o.put("category", item.category.name)
            o.put("triggerTimeMillis", item.triggerTimeMillis)
            o.put("repeatType", item.repeatType.name)
            o.put("intervalHours", item.intervalHours)
            val wArr = JSONArray()
            item.weeklyDays.forEach { wArr.put(it) }
            o.put("weeklyDays", wArr)
            o.put("monthlyDay", item.monthlyDay)
            val pArr = JSONArray()
            item.preAlertMinutes.forEach { pArr.put(it) }
            o.put("preAlertMinutes", pArr)
            o.put("fullScreenAlarm", item.fullScreenAlarm)
            o.put("isCompleted", item.isCompleted)
            o.put("completedCount", item.completedCount)
            o.put("missedCount", item.missedCount)
            arr.put(o)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_REMINDERS, arr.toString())
            .apply()
    }

    fun upsertReminder(context: Context, item: ReminderItem) {
        val all = getAllReminders(context).toMutableList()
        val idx = all.indexOfFirst { it.id == item.id }
        if (idx >= 0) {
            all[idx] = item
        } else {
            all.add(item)
        }
        saveAllReminders(context, all)
        if (!item.isCompleted) {
            AlarmScheduler.scheduleReminder(context, item)
        } else {
            AlarmScheduler.cancelReminder(context, item)
        }
    }

    fun deleteReminder(context: Context, id: String) {
        val all = getAllReminders(context).toMutableList()
        val target = all.firstOrNull { it.id == id }
        if (target != null) {
            AlarmScheduler.cancelReminder(context, target)
            all.removeAll { it.id == id }
            saveAllReminders(context, all)
        }
    }

    fun markReminderDone(context: Context, id: String) {
        val all = getAllReminders(context).toMutableList()
        val idx = all.indexOfFirst { it.id == id }
        if (idx < 0) return

        val item = all[idx]
        AlarmScheduler.cancelReminder(context, item)

        appendHistory(
            context,
            HistoryLog(
                id = UUID.randomUUID().toString(),
                reminderId = item.id,
                title = item.title,
                category = item.category,
                scheduledTimeMillis = item.triggerTimeMillis,
                actionTimeMillis = System.currentTimeMillis(),
                isCompleted = true
            )
        )

        if (item.repeatType == RepeatType.ONCE) {
            all[idx] = item.copy(
                isCompleted = true,
                completedCount = item.completedCount + 1
            )
            saveAllReminders(context, all)
        } else {
            val nextTime = computeNextOccurrenceMillis(item, System.currentTimeMillis())
            val updated = item.copy(
                triggerTimeMillis = nextTime,
                isCompleted = false,
                completedCount = item.completedCount + 1
            )
            all[idx] = updated
            saveAllReminders(context, all)
            AlarmScheduler.scheduleReminder(context, updated)
        }
    }

    fun syncMissedReminders(context: Context) {
        val now = System.currentTimeMillis()
        val graceMillis = 10 * 60 * 1000L // 10 minutes grace window
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val loggedSet = mutableSetOf<String>()
        try {
            val arr = JSONArray(prefs.getString(KEY_MISSED_KEYS, "[]") ?: "[]")
            for (i in 0 until arr.length()) loggedSet.add(arr.getString(i))
        } catch (_: Exception) {
        }

        val all = getAllReminders(context).toMutableList()
        var changed = false
        for (i in all.indices) {
            val item = all[i]
            if (!item.isCompleted && (item.triggerTimeMillis + graceMillis) < now) {
                val occKey = "${item.id}_${item.triggerTimeMillis}"
                if (!loggedSet.contains(occKey)) {
                    loggedSet.add(occKey)
                    appendHistory(
                        context,
                        HistoryLog(
                            id = UUID.randomUUID().toString(),
                            reminderId = item.id,
                            title = item.title,
                            category = item.category,
                            scheduledTimeMillis = item.triggerTimeMillis,
                            actionTimeMillis = now,
                            isCompleted = false
                        )
                    )
                    all[i] = item.copy(missedCount = item.missedCount + 1)
                    changed = true
                }
            }
        }
        if (changed) {
            saveAllReminders(context, all)
            val newArr = JSONArray()
            loggedSet.takeLast(500).forEach { newArr.put(it) }
            prefs.edit().putString(KEY_MISSED_KEYS, newArr.toString()).apply()
        }
    }

    fun computeNextOccurrenceMillis(item: ReminderItem, fromMillis: Long): Long {
        val zone = ZoneId.systemDefault()
        val baseDt = LocalDateTime.ofInstant(Instant.ofEpochMilli(item.triggerTimeMillis), zone)
        val nowDt = LocalDateTime.ofInstant(Instant.ofEpochMilli(fromMillis), zone)

        var candidate = baseDt
        when (item.repeatType) {
            RepeatType.ONCE -> {
                return item.triggerTimeMillis
            }
            RepeatType.DAILY -> {
                while (!candidate.isAfter(nowDt)) {
                    candidate = candidate.plusDays(1)
                }
            }
            RepeatType.ALTERNATE_DAY -> {
                while (!candidate.isAfter(nowDt)) {
                    candidate = candidate.plusDays(2)
                }
            }
            RepeatType.EVERY_X_HOURS -> {
                val step = item.intervalHours.coerceAtLeast(1).toLong()
                while (!candidate.isAfter(nowDt)) {
                    candidate = candidate.plusHours(step)
                }
            }
            RepeatType.WEEKLY -> {
                val validDays = if (item.weeklyDays.isEmpty()) {
                    listOf(baseDt.dayOfWeek.value)
                } else {
                    item.weeklyDays.sorted()
                }
                candidate = nowDt.withHour(baseDt.hour).withMinute(baseDt.minute).withSecond(0).withNano(0)
                if (!candidate.isAfter(nowDt)) {
                    candidate = candidate.plusDays(1)
                }
                for (offset in 0..14) {
                    val test = candidate.plusDays(offset.toLong())
                    if (test.dayOfWeek.value in validDays && test.isAfter(nowDt)) {
                        candidate = test
                        break
                    }
                }
            }
            RepeatType.MONTHLY -> {
                val targetDay = item.monthlyDay.coerceIn(1, 31)
                var ym = nowDt.withHour(baseDt.hour).withMinute(baseDt.minute).withSecond(0).withNano(0)
                val maxDayThisMonth = ym.toLocalDate().lengthOfMonth()
                candidate = ym.withDayOfMonth(targetDay.coerceAtMost(maxDayThisMonth))
                if (!candidate.isAfter(nowDt)) {
                    ym = ym.plusMonths(1)
                    val maxNext = ym.toLocalDate().lengthOfMonth()
                    candidate = ym.withDayOfMonth(targetDay.coerceAtMost(maxNext))
                }
            }
        }
        return candidate.atZone(zone).toInstant().toEpochMilli()
    }

    fun getHistoryLogs(context: Context): List<HistoryLog> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        val list = mutableListOf<HistoryLog>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    HistoryLog(
                        id = o.getString("id"),
                        reminderId = o.optString("reminderId", ""),
                        title = o.getString("title"),
                        category = ReminderCategory.fromName(o.optString("category", "DAILY")),
                        scheduledTimeMillis = o.getLong("scheduledTimeMillis"),
                        actionTimeMillis = o.getLong("actionTimeMillis"),
                        isCompleted = o.getBoolean("isCompleted")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list.sortedByDescending { it.actionTimeMillis }
    }

    private fun appendHistory(context: Context, log: HistoryLog) {
        val existing = getHistoryLogs(context).toMutableList()
        existing.add(0, log)
        val trimmed = existing.take(200)
        val arr = JSONArray()
        for (h in trimmed) {
            val o = JSONObject()
            o.put("id", h.id)
            o.put("reminderId", h.reminderId)
            o.put("title", h.title)
            o.put("category", h.category.name)
            o.put("scheduledTimeMillis", h.scheduledTimeMillis)
            o.put("actionTimeMillis", h.actionTimeMillis)
            o.put("isCompleted", h.isCompleted)
            arr.put(o)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_HISTORY, arr.toString())
            .apply()
    }

    fun clearHistory(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_HISTORY, "[]")
            .apply()
    }

    fun getWeeklyPlan(context: Context): List<WeeklyPlanDay> {
        ensureSeeded(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_WEEKLY, "[]") ?: "[]"
        val list = mutableListOf<WeeklyPlanDay>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    WeeklyPlanDay(
                        dayOfWeek = o.getInt("dayOfWeek"),
                        dayTitle = o.getString("dayTitle"),
                        mealPlan = o.optString("mealPlan", ""),
                        schedulePlan = o.optString("schedulePlan", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list.sortedBy { it.dayOfWeek }
    }

    fun saveWeeklyPlan(context: Context, days: List<WeeklyPlanDay>) {
        val arr = JSONArray()
        for (d in days) {
            val o = JSONObject()
            o.put("dayOfWeek", d.dayOfWeek)
            o.put("dayTitle", d.dayTitle)
            o.put("mealPlan", d.mealPlan)
            o.put("schedulePlan", d.schedulePlan)
            arr.put(o)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_WEEKLY, arr.toString())
            .apply()
    }

    fun updateWeeklyDay(context: Context, updatedDay: WeeklyPlanDay) {
        val all = getWeeklyPlan(context).toMutableList()
        val idx = all.indexOfFirst { it.dayOfWeek == updatedDay.dayOfWeek }
        if (idx >= 0) {
            all[idx] = updatedDay
            saveWeeklyPlan(context, all)
        }
    }
}
