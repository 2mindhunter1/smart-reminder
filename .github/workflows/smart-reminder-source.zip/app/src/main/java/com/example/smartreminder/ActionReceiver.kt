package com.example.smartreminder

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class ActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_DONE = "com.example.smartreminder.ACTION_DONE"
        const val ACTION_SNOOZE = "com.example.smartreminder.ACTION_SNOOZE"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getStringExtra(AlarmScheduler.EXTRA_REMINDER_ID) ?: return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(reminderId.hashCode())

        when (intent.action) {
            ACTION_DONE -> {
                ReminderRepository.markReminderDone(context, reminderId)
                Toast.makeText(context, "Kaam Done mark thai gayu!", Toast.LENGTH_SHORT).show()
            }
            ACTION_SNOOZE -> {
                AlarmScheduler.scheduleSnooze(context, reminderId, 10)
                Toast.makeText(context, "10 minute pachhi fari yaad karavshe", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
