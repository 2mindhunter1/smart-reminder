package com.example.smartreminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object AlarmScheduler {

    const val EXTRA_REMINDER_ID = "extra_reminder_id"
    const val EXTRA_IS_PRE_ALERT = "extra_is_pre_alert"
    const val EXTRA_PRE_ALERT_LABEL = "extra_pre_alert_label"

    fun scheduleReminder(context: Context, item: ReminderItem) {
        if (item.isCompleted) {
            cancelReminder(context, item)
            return
        }
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()

        // 1. Main exact alarm
        if (item.triggerTimeMillis > now - 60_000L) {
            val triggerAt = maxOf(item.triggerTimeMillis, now + 2_000L)
            val mainPi = buildPendingIntent(
                context = context,
                reminderId = item.id,
                requestCode = (item.id + "_main").hashCode(),
                isPreAlert = false,
                preLabel = ""
            )
            setExactAlarmClock(context, alarmManager, triggerAt, mainPi)
        }

        // 2. Multi-stage Pre-Alerts (e.g. 1 day before, 2 hours before, 15 mins before)
        for (minsBefore in item.preAlertMinutes) {
            val preTime = item.triggerTimeMillis - (minsBefore * 60_000L)
            if (preTime > now + 2_000L) {
                val label = formatPreAlertLabel(minsBefore)
                val prePi = buildPendingIntent(
                    context = context,
                    reminderId = item.id,
                    requestCode = (item.id + "_pre_" + minsBefore).hashCode(),
                    isPreAlert = true,
                    preLabel = label
                )
                setExactAlarmClock(context, alarmManager, preTime, prePi)
            }
        }
    }

    fun scheduleSnooze(context: Context, reminderId: String, minutes: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = System.currentTimeMillis() + (minutes * 60_000L)
        val pi = buildPendingIntent(
            context = context,
            reminderId = reminderId,
            requestCode = (reminderId + "_snooze").hashCode(),
            isPreAlert = false,
            preLabel = ""
        )
        setExactAlarmClock(context, alarmManager, triggerAt, pi)
    }

    fun cancelReminder(context: Context, item: ReminderItem) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val codes = mutableListOf(
            (item.id + "_main").hashCode(),
            (item.id + "_snooze").hashCode()
        )
        for (m in listOf(15, 30, 60, 120, 1440)) {
            codes.add((item.id + "_pre_" + m).hashCode())
        }
        for (code in codes) {
            val intent = Intent(context, AlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context,
                code,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) {
                alarmManager.cancel(pi)
                pi.cancel()
            }
        }
    }

    fun rescheduleAll(context: Context) {
        val all = ReminderRepository.getAllReminders(context)
        for (item in all) {
            if (!item.isCompleted) {
                scheduleReminder(context, item)
            }
        }
    }

    private fun setExactAlarmClock(
        context: Context,
        alarmManager: AlarmManager,
        triggerAtMillis: Long,
        operation: PendingIntent
    ) {
        try {
            val showIntent = Intent(context, MainActivity::class.java)
            val showPi = PendingIntent.getActivity(
                context,
                0,
                showIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val info = AlarmManager.AlarmClockInfo(triggerAtMillis, showPi)
            alarmManager.setAlarmClock(info, operation)
        } catch (_: Exception) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operation)
        }
    }

    private fun buildPendingIntent(
        context: Context,
        reminderId: String,
        requestCode: Int,
        isPreAlert: Boolean,
        preLabel: String
    ): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_REMINDER_ID, reminderId)
            putExtra(EXTRA_IS_PRE_ALERT, isPreAlert)
            putExtra(EXTRA_PRE_ALERT_LABEL, preLabel)
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun formatPreAlertLabel(mins: Int): String {
        return when (mins) {
            15 -> "15 Minute Pehla Alert"
            30 -> "30 Minute Pehla Alert"
            60 -> "1 Kalak Pehla Alert"
            120 -> "2 Kalak Pehla Alert"
            1440 -> "1 Divas Pehla Alert"
            else -> "$mins Min Pehla Alert"
        }
    }
}
