package com.example.smartreminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "smart_reminder_alarm_channel_v1"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getStringExtra(AlarmScheduler.EXTRA_REMINDER_ID) ?: return
        val isPreAlert = intent.getBooleanExtra(AlarmScheduler.EXTRA_IS_PRE_ALERT, false)
        val preLabel = intent.getStringExtra(AlarmScheduler.EXTRA_PRE_ALERT_LABEL) ?: ""

        val item = ReminderRepository.getReminderById(context, reminderId) ?: return
        if (item.isCompleted) return

        createChannelIfNeeded(context)

        val alertIntent = Intent(context, AlarmAlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(AlarmScheduler.EXTRA_REMINDER_ID, item.id)
            putExtra(AlarmScheduler.EXTRA_IS_PRE_ALERT, isPreAlert)
            putExtra(AlarmScheduler.EXTRA_PRE_ALERT_LABEL, preLabel)
        }
        val fullScreenPi = PendingIntent.getActivity(
            context,
            (item.id + "_fs").hashCode(),
            alertIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val doneIntent = Intent(context, ActionReceiver::class.java).apply {
            action = ActionReceiver.ACTION_DONE
            putExtra(AlarmScheduler.EXTRA_REMINDER_ID, item.id)
        }
        val donePi = PendingIntent.getBroadcast(
            context,
            (item.id + "_done").hashCode(),
            doneIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozeIntent = Intent(context, ActionReceiver::class.java).apply {
            action = ActionReceiver.ACTION_SNOOZE
            putExtra(AlarmScheduler.EXTRA_REMINDER_ID, item.id)
        }
        val snoozePi = PendingIntent.getBroadcast(
            context,
            (item.id + "_snz").hashCode(),
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val headerText = if (isPreAlert && preLabel.isNotEmpty()) {
            "$preLabel • ${item.category.label}"
        } else {
            "Reminder • ${item.category.label}"
        }

        val notifBuilder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(item.title)
            .setContentText(if (item.note.isNotEmpty()) item.note else headerText)
            .setSubText(headerText)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(!isPreAlert)
            .setAutoCancel(isPreAlert)
            .setContentIntent(fullScreenPi)
            .addAction(android.R.drawable.ic_menu_send, "Done", donePi)
            .addAction(android.R.drawable.ic_popup_reminder, "Snooze 10m", snoozePi)

        if (!isPreAlert && item.fullScreenAlarm) {
            notifBuilder.setFullScreenIntent(fullScreenPi, true)
        }

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(item.id.hashCode(), notifBuilder.build())

        if (!isPreAlert && item.fullScreenAlarm) {
            try {
                context.startActivity(alertIntent)
            } catch (_: Exception) {
            }
        }
    }

    private fun createChannelIfNeeded(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                val ch = NotificationChannel(
                    CHANNEL_ID,
                    "Smart Reminder Alarms",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "High-priority full-screen reminder alerts"
                    enableVibration(true)
                }
                nm.createNotificationChannel(ch)
            }
        }
    }
}
