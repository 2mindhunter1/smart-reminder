package com.example.smartreminder

import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class AlarmAlertActivity : AppCompatActivity() {

    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var reminderId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm_alert)

        reminderId = intent.getStringExtra(AlarmScheduler.EXTRA_REMINDER_ID) ?: ""
        val isPreAlert = intent.getBooleanExtra(AlarmScheduler.EXTRA_IS_PRE_ALERT, false)
        val preLabel = intent.getStringExtra(AlarmScheduler.EXTRA_PRE_ALERT_LABEL) ?: ""

        val item = ReminderRepository.getReminderById(this, reminderId)
        if (item == null) {
            finish()
            return
        }

        val tvAlertBadge: TextView = findViewById(R.id.tvAlertBadge)
        val tvAlertTitle: TextView = findViewById(R.id.tvAlertTitle)
        val tvAlertTime: TextView = findViewById(R.id.tvAlertTime)
        val tvAlertNote: TextView = findViewById(R.id.tvAlertNote)
        val btnAlarmDone: MaterialButton = findViewById(R.id.btnAlarmDone)
        val btnSnooze5: MaterialButton = findViewById(R.id.btnSnooze5)
        val btnSnooze15: MaterialButton = findViewById(R.id.btnSnooze15)

        tvAlertBadge.text = if (isPreAlert && preLabel.isNotEmpty()) {
            "$preLabel • ${item.category.label}"
        } else {
            item.category.label
        }
        tvAlertTitle.text = item.title

        val dt = LocalDateTime.ofInstant(
            Instant.ofEpochMilli(item.triggerTimeMillis),
            ZoneId.systemDefault()
        )
        val fmt = DateTimeFormatter.ofPattern("hh:mm a • dd MMM yyyy", Locale.ENGLISH)
        tvAlertTime.text = dt.format(fmt)

        tvAlertNote.text = if (item.note.isNotEmpty()) {
            item.note
        } else {
            "Repeat: ${item.repeatType.label}"
        }

        startAlarmSoundAndVibration()

        btnAlarmDone.setOnClickListener {
            stopAlarmSoundAndVibration()
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(reminderId.hashCode())
            ReminderRepository.markReminderDone(this, reminderId)
            Toast.makeText(this, "Done! Aagal nu reminder set thai gayu chhe.", Toast.LENGTH_SHORT).show()
            finish()
        }

        btnSnooze5.setOnClickListener {
            stopAlarmSoundAndVibration()
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(reminderId.hashCode())
            AlarmScheduler.scheduleSnooze(this, reminderId, 5)
            Toast.makeText(this, "5 minute pachhi fari alarm vagse", Toast.LENGTH_SHORT).show()
            finish()
        }

        btnSnooze15.setOnClickListener {
            stopAlarmSoundAndVibration()
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(reminderId.hashCode())
            AlarmScheduler.scheduleSnooze(this, reminderId, 15)
            Toast.makeText(this, "15 minute pachhi fari alarm vagse", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun startAlarmSoundAndVibration() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    isLooping = true
                }
                play()
            }
        } catch (_: Exception) {
        }

        try {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            val pattern = longArrayOf(0, 700, 500, 700, 500)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        } catch (_: Exception) {
        }
    }

    private fun stopAlarmSoundAndVibration() {
        try {
            ringtone?.stop()
        } catch (_: Exception) {
        }
        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        stopAlarmSoundAndVibration()
        super.onDestroy()
    }
}
